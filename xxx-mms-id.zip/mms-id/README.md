# mms-id 
# xxx-id - editor 
- ID System for VorpCore

# Features
 
- ID Card
- Show ID ( Close Player )
- Change ID Picture https://postimg.cc ( USE DIREKT LINK ) Size must be 200x200 px
- BuyHuntingID for X Days ( You need to Burn you Hunting License if its Open to delete it )
- Show BuyHuntingID ( Close Player )
- Joblock if Hunter Job should Create Hunting Licenses ( Close Player )
- Ger / End Translation 
- create an idcard item and add it to your database to use the identity as an item! I'm going to leave everything inside the installation folder with all the items to run this script!
-  Always leave the menu before utils ex: 1 - ensure Feather Menu
3 -ensure bcc-utils

# Changelog

- 1.1.3 Initial Realease
- 1.1.4 Added Joblock for hunting ids
- 1.1.5 Added Joblock Hunter can Give Himself a Unlimited Hunting ID Valid for 9999 Days
- 1.1.6 Added Hunting ID SQL File

# installation 

- Run the SQL file to add Tables in your DB


# Required
- Vorp_Core 
- Feather Menu by BCC 
- bcc-utils


# CREDITS
- Discord markusmueller 
- https://github.com/RetryR1v2/mms-id 
- English Translation by Vecktor
- Discord xxx-comunity
- https://discord.gg/XAXneaffyy
- Portugues Br Translation by xxx

- xxx was the one who translated it into Brazilian Portuguese, changed panel colors, blip changes, new coordinates, basically configured! All credit goes to whoever created all the writing, just a few improvements were made #xxx