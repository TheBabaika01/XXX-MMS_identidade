Config = {}


Config.defaultlang = "pt_br_lang" -- Set Language (Current Languages: "en_lang" English, "de_lang" German)

-----------------------------------------------------------------------------------
---------------------------------ID Settings----------------------------------
-----------------------------------------------------------------------------------

Config.AusweisBlips = true
Config.CreateNPC = true
Config.Show3dText = true
Config.AusweisLocations = {

    {
        coords = vector3(-175.47, 631.76, 114.09),   --- Also the Location of Blip and Npc (Valentine)
        NpcHeading = 322.61,
    },
    {
        coords = vector3(1230.07, -1298.43, 76.9),   --- Also the Location of Blip and Npc (Rhodes)
        NpcHeading = 227.52,
    },
    {
        coords = vector3(2747.93, -1396.37, 46.18),   --- Also the Location of Blip and Npc (Sanit Denis)
        NpcHeading = 32.97,
    },

}

Config.AusweisPreis = 15
Config.AusweisVerlorenPreis = 20
Config.ChangeFotoPreis = 10

Config.JobLockHunting = true
Config.Command = 'createhuntingid' -- Command TO Popup HunterLicense Menü
Config.Jobs =  {
    {JobName = 'hunter'},
}
Config.HuntingLicensePrice = 10
Config.HuntingLicenseVerlorenPrice = 30
Config.HuntingIdPicture = 'https://i.postimg.cc/KvJYFgW5/jagt.png' -- <-- Picture of Directlink from  https://postimg.cc Readme for Picture Info